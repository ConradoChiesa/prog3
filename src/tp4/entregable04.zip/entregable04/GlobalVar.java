package tp4.entregable04;

public interface GlobalVar {
    final static int DIAS_DE_APERTURA = 100;

    final static int DIAS_PREFERIDOS = 8;
    int getAlgo();
}
