package tp5.entregable05;

public interface GlobalVar {
    final static int DIAS_DE_APERTURA = 10;

    final static int DIAS_PREFERIDOS = 3;

}
